class home extends Phaser.Scene {
    constructor() {
      super({ key: "accueil" }); 
    }


    preload() {
        this.load.image("background", "./img/accueil.png");
        this.load.image("logos", "./img/logo.png");
        this.load.image("menu-brun", "./asset/green-buttons-text.png");
        this.load.image("menu-gris", "./asset/ram-buttons.png");
        this.load.image("menu-orange", "./asset/orange-button-text.png");
    }

    create() {

        //image de fond accueil
        let background = this.add.image(0, 0, 'background');
            background.setOrigin(0, 0); 
            background.setDisplaySize(this.scale.width, this.scale.height);

        let logos= this.add.image(0, 0, 'logos').setScale(0.12);
            logos.setOrigin(0, 0); 
            logos.setPosition(10, 10);


        //boutton
       let start = this.add.image(0, 0, 'menu-brun').setScale(1.2);
            start.setOrigin(0, 0); 
            start.setCrop(65, 0, 63, 30);
            start.setPosition(120, 260);

       let credit = this.add.image(0, 0, 'menu-brun').setScale(1.2);
            credit.setOrigin(0, 0); 
            credit.setCrop(385, 0, 78, 30);
            credit.setPosition(-120, 260);

       let info = this.add.image(0, 0, 'menu-brun').setScale(1.2);
            info.setOrigin(0, 0); 
            info.setCrop(256, 192, 65, 30);
            info.setPosition(198, 30);

       //button sons
       let sonsBase = this.add.image(0, 0, 'menu-gris').setScale(1.5,1.3);
            sonsBase.setOrigin(0, 0); 
            sonsBase.setCrop(32, 96, 32, 32);
            sonsBase.setPosition(684, -102);


       let sons = this.add.image(0, 0, 'menu-gris').setScale(1.3);
            sons.setOrigin(0, 0); 
            sons.setCrop(385, 17, 15, 15);
            sons.setPosition(246, 7);


       //interaction boutton menu 
       //commencer le jeu
        let interactiveStart = new Phaser.GameObjects.Rectangle(this, 
            start.x + 52 + 63, start.y + 17, 63, 30);
            this.add.existing(interactiveStart);
        

        interactiveStart.setInteractive();
        interactiveStart.on("pointerover", () => {
           start.setCrop(128, 0, 63, 30);
           start.setPosition(43, 261);
       });

       interactiveStart.on("pointerout", () => { 
           start.setCrop(65, 0, 63, 30);
           start.setPosition(120, 260);
       });

       interactiveStart.on("pointerdown", () => {
            this.scene.start("jeu");
       })


       //interaction boutton menu
       //les credits
       let interactiveCredit = new Phaser.GameObjects.Rectangle(this, 
            credit.x + 445 + 63, credit.y + 17, 85, 30);
            this.add.existing(interactiveCredit);

        interactiveCredit.setInteractive();
        interactiveCredit.on("pointerover", () => {
           credit.setCrop(545, 0, 78, 30);
           credit.setPosition(-312, 261);
       });

       interactiveCredit.on("pointerout", () => { 
           credit.setCrop(385, 0, 78, 30);
           credit.setPosition(-120, 260);
       });

       interactiveCredit.on("pointerdown", () => {
            this.scene.start("credits");
       })


       //interaction boutton menu
       //information comment jouer
       let interactiveInfo = new Phaser.GameObjects.Rectangle(this, 
            info.x + 280 + 65, info.y + 246, 70, 30);
            this.add.existing(interactiveInfo);

        interactiveInfo.setInteractive();

        interactiveInfo.on("pointerover", () => {
           info.setCrop(320, 191, 65, 31 );
           info.setPosition(121, 31);
       });

       interactiveInfo.on("pointerout", () => { 
           info.setCrop(256, 192, 65, 30);
           info.setPosition(198, 30 );
       });

       interactiveInfo.on("pointerdown", () => {
            this.scene.start("infos");
       })

       
       //interaction button menu
       //sons activer desactiver
       let interactiveSons = new Phaser.GameObjects.Rectangle(this, 
           sons.x + -16 + 526, sons.y + 33, 32, 30);
            this.add.existing(interactiveSons);

        let alterne = true; 

       interactiveSons.setInteractive();

       interactiveSons.on("pointerover", () => {
            sonsBase.setCrop(64, 96, 32, 32);
            sonsBase.setPosition(636, -102);
      });

        interactiveSons.on("pointerout", () => { 
            sonsBase.setCrop(32, 96, 32, 32);
            sonsBase.setPosition(684, -102);
        });
        
       interactiveSons.on("pointerdown", () => {
 
           if (alterne) {
               sons.setCrop(400, 17, 15, 15);
               sons.setPosition(226, 7);
           } else {
               sons.setCrop(385, 17, 15, 15);
               sons.setPosition(246, 7);
           }
           alterne = !alterne; 
       });

    } 

    
    update() {

    }
    
}












