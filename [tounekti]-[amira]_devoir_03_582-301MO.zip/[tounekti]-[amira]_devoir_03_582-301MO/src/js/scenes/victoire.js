class victoire extends Phaser.Scene {
    constructor() {
        super({ key: "win" }); 
    }

    preload() {
        this.load.image("background", "./img/accueil.png");
        this.load.image("logos", "./img/logo.png");
        this.load.image("menu-brun", "./asset/green-buttons-text.png");
        this.load.image("menu-gris", "./asset/ram-buttons.png");
        this.load.image("menu-orange", "./asset/orange-button-text.png");
        this.load.image("menu-purple", "./asset/purple-buttons-text.png");
        this.load.image("success", "./img/success.png");
    }

    create() {
        let background = this.add.graphics();
            background.fillStyle(0x90dcf3);
            background.fillRect(0,0, this.scale.width, this.scale.height); 

            let success = this.add.image(0, 0, 'success').setScale(0.4);
            success.setOrigin(0, 0); 
            success.setPosition(280, 20);
        
        //boutton
        //GameOver
        let quit = this.add.image(0, 0, 'menu-purple').setScale(1.2);
            quit.setOrigin(0, 0); 
            quit.setCrop(64, 193, 63, 30);
            quit.setPosition(295, 60);


        //interaction button menu
       //retoure a l'accueil
       let interactiveQuit = new Phaser.GameObjects.Rectangle(this, 
            quit.x + 70 + 65, quit.y + 246, 70, 30);
            this.add.existing(interactiveQuit);

        interactiveQuit.setInteractive();

        interactiveQuit.on("pointerover", () => {
            quit.setCrop(128, 193, 63, 30);
            quit.setPosition(218, 61);
       });

       interactiveQuit.on("pointerout", () => { 
            quit.setCrop(64, 193, 63, 30);
            quit.setPosition(295, 60);
       });

       interactiveQuit.on("pointerdown", () => {
            this.scene.start("accueil");
       });
 
    }

    update() {

    }

}