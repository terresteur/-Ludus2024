class information extends Phaser.Scene {
    constructor() {
        super({ key: "infos" }); 
    }

    preload() {
        this.load.image("background", "./img/accueil.png");
        this.load.image("logos", "./img/logo.png");
        this.load.image("menu-brun", "./asset/green-buttons-text.png");
        this.load.image("menu-gris", "./asset/ram-buttons.png");
        this.load.image("menu-orange", "./asset/orange-button-text.png");
    }

    create() {
        let background = this.add.image(0, 0, 'background');
            background.setOrigin(0, 0); 
            background.setDisplaySize(this.scale.width, this.scale.height);

        //boutton
        //retoure a l'accueil
        let homeBase = this.add.image(0, 0, 'menu-gris').setScale(1.5,1.3);
            homeBase.setOrigin(0, 0); 
            homeBase.setCrop(32, 96, 32, 32);
            homeBase.setPosition(684, -102);
 
 
        let home = this.add.image(0, 0, 'menu-gris').setScale(1.3);
            home.setOrigin(0, 0); 
            home.setCrop(288, 0, 17, 17);
            home.setPosition(371, 27);


        //interaction button menu
       //retoure a l'accueil
        let interactiveHome = new Phaser.GameObjects.Rectangle(this, 
            home.x + 6 + 380, home.y + 14, 32, 30);
            this.add.existing(interactiveHome);


        interactiveHome.setInteractive();

        interactiveHome.on("pointerover", () => {
            homeBase.setCrop(64, 96, 32, 32);
            homeBase.setPosition(636, -102);
       });
 
       interactiveHome.on("pointerout", () => { 
            homeBase.setCrop(32, 96, 32, 32);
            homeBase.setPosition(684, -102);
       });

       interactiveHome.on("pointerdown", () => {
            this.scene.start("accueil");
       })

    }

    update() {

    }

}