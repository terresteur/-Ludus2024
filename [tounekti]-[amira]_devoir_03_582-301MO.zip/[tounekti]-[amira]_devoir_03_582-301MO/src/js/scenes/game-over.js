class gameOver extends Phaser.Scene {
    constructor() {
        super({ key: "gameFinish" }); 
    }

    preload() {
        this.load.image("background", "./img/accueil.png");
        this.load.image("logos", "./img/logo.png");
        this.load.image("menu-brun", "./asset/green-buttons-text.png");
        this.load.image("menu-gris", "./asset/ram-buttons.png");
        this.load.image("menu-orange", "./asset/orange-button-text.png");
        this.load.image("img-over", "./img/game_over.png");
    }

    create() {
        //image de fond accueil
        let background = this.add.graphics();
            background.fillStyle(0x000000);
            background.fillRect(0,0, this.scale.width, this.scale.height); 

        let over= this.add.image(0, 0, 'img-over').setScale(0.4);
            over.setOrigin(0, 0); 
            over.setPosition(280, 0);
            

        //boutton
        //GameOver
        let restart = this.add.image(0, 0, 'menu-orange').setScale(1.2);
            restart.setOrigin(0, 0); 
            restart.setCrop(385, 32, 78, 31);
            restart.setPosition(-25, 252);
 
        let quit = this.add.image(0, 0, 'menu-orange').setScale(1.2);
            quit.setOrigin(0, 0); 
            quit.setCrop(64, 193, 63, 30);
            quit.setPosition(215, 60);


        //interaction button menu
       //retoure a l'accueil
       let interactiveQuit = new Phaser.GameObjects.Rectangle(this, 
            quit.x + 50 + 65, quit.y + 246, 70, 30);
            this.add.existing(interactiveQuit);

        interactiveQuit.setInteractive();

        interactiveQuit.on("pointerover", () => {
            quit.setCrop(128, 193, 63, 30);
            quit.setPosition(138, 61);
       });

       interactiveQuit.on("pointerout", () => { 
            quit.setCrop(64, 193, 63, 30);
            quit.setPosition(215, 60);
       });

       interactiveQuit.on("pointerdown", () => {
            this.scene.start("accueil");
       })


        //interaction button menu
       //recomencer la partie
       let interactiveRetry = new Phaser.GameObjects.Rectangle(this, 
            restart.x + 444 + 65, restart.y + 54, 90, 30);
            this.add.existing(interactiveRetry);

        interactiveRetry.setInteractive();
        interactiveRetry.on("pointerover", () => {
            restart.setCrop(545, 32, 78, 31);
            restart.setPosition(-217, 253);
       });

       interactiveRetry.on("pointerout", () => { 
            restart.setCrop(385, 32, 78, 31);
            restart.setPosition(-25, 252);
       });

       interactiveRetry.on("pointerdown", () => {
            this.scene.start("jeu");
       })

    }

    update() {

    }

}